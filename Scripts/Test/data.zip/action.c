Action()
{

	lr_start_transaction("home page");

	return 0;
}